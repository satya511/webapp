import create from "zustand";

const useIoStore = create((set) => {
  return {
  "Home": {}
}});

export default useIoStore;
